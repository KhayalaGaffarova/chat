<?php
$con = mysqli_connect("localhost","root","","chat") or die("Connection wasn't established");

?>

